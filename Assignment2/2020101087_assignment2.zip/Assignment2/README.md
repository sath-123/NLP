## main functions
* TagsAndWords()
*  Training()
*  Evaluation()

## executing the file
- we can just run the file typing pos_tagger.py in the directory where this file is located
- It will take take sentences and gives there pos tags 
- you can give as many sentences as you want ,because it a while(1) is there to take sentences one after another
- need to change the path of the saved model in code ,to use the model
- if we give the sentences which has punctuations,output will ignore the punctuations because train data doesn't have any punctuation marks
